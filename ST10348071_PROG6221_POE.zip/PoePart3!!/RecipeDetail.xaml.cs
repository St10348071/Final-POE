﻿using PoePart3__;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PoePart3__
{
    /// <summary>
    /// Interaction logic for RecipeDetail.xaml
    /// </summary>
    public partial class RecipeDetail : Window
    {
        private Recipe currentRecipe;
        public RecipeDetail(Recipe recipe)
        {
            InitializeComponent();
            currentRecipe = recipe;
            DisplayRecipeDetails();
        }

        private void DisplayRecipeDetails()
        {
            RecipeNameTextBlock.Text = currentRecipe.RecipeName;
            IngredientsStackPanel.Children.Clear();
            foreach (var ingredient in currentRecipe.Ingredients)
            {
                TextBlock ingredientTextBlock = new TextBlock
                {
                    Text = $"- {ingredient.Quantity} {ingredient.UnitOfMeasurement} of {ingredient.Name} ({ingredient.Calories} calories) ({ingredient.FoodGroup})"
                };
                IngredientsStackPanel.Children.Add(ingredientTextBlock);
            }

            StepsStackPanel.Children.Clear();
            foreach (var step in currentRecipe.Steps)
            {
                TextBlock stepTextBlock = new TextBlock
                {
                    Text = $"{step.StepNumber}. {step.Description}"
                };
                StepsStackPanel.Children.Add(stepTextBlock);
            }

            TotalCaloriesTextBlock.Text = currentRecipe.TotalCalories.ToString();
        }

        private void ScaleButton_Click(object sender, RoutedEventArgs e)
        {
            ScaleRecipe scaleWindow = new ScaleRecipe(currentRecipe);
            if (scaleWindow.ShowDialog() == true)
            {
                double scaleFactor = scaleWindow.ScaleFactor;
                currentRecipe.Scale(scaleFactor);
                DisplayRecipeDetails();
            }
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            currentRecipe.ResetIngredientValues();
            DisplayRecipeDetails();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            ViewRecipes viewRecipesWindow = new ViewRecipes();
            viewRecipesWindow.Show();
            this.Close();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            RecipeRepository.Recipes.Remove(currentRecipe);
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}

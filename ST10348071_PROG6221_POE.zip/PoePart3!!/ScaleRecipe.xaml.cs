﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PoePart3__
{
    /// <summary>
    /// Interaction logic for ScaleRecipe.xaml
    /// </summary>
    public partial class ScaleRecipe : Window
    {
        private Recipe currentRecipe;

        public double ScaleFactor { get; set; }

        public ScaleRecipe()
        {
            InitializeComponent();
        }

        public ScaleRecipe(Recipe currentRecipe)
        {
            this.currentRecipe = currentRecipe;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(ScaleFactorTextBox.Text, out double scaleFactor) && scaleFactor > 0)
            {
                ScaleFactor = scaleFactor;
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Please enter a valid scale factor.", "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
